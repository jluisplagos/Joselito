# Viscofan · fase C · turno 1 · 2026-11-04 · motor B

## 1. Una sola historia

Leo las 52 celdas de A y B como si fueran de otro: «intensively consider any evidence tending to disconfirm any hypothesis of his» (PCA p.528; HIM).

Lo que calcula la hoja: MALO 35,39 €, NORMAL 47,56 €, BUENO 63,33 €, ponderado 46,88 € (B78:D78, C83) frente a un precio de 54,70 €. El precio está por encima del NORMAL y del ponderado; solo el BUENO lo supera. Es la historia de la fase A: buen negocio de nicho, foso que la Historia confirma pero más estrecho de lo que dice la cuota, y un precio sin margen (C13 = No, C20 = Riesgo real alto).

- **Peso del terminal**: 48 % / 59 % / 63 %. Ninguno pasa del 75 %: no hay G16. El valor no depende sobre todo del año 11 en adelante.
- **Salto del año 11**: 2,8 / 3,6 / 8,2 puntos. En el MALO y el NORMAL la rentabilidad marginal de los años 1–10 (10,8 % y 14,6 %) baja poco al pasar al terminal (8 % y 11 %). En el BUENO cae de 20,2 % a 12 %: es G8 y lo justifico abajo.
- **DCF inverso**: con el margen, el S2C y el terminal del NORMAL, el precio de 54,70 € descuenta un crecimiento de ventas del 8,2 % anual en los años 1–5 (C86). Es más que mi BUENO (7 %) y más que la mejor racha de la década (5,8 % anual en 2016-2021 [cálculo Historia D28:H28]). El precio de Sí descuenta un 1,7 %. Lo que se paga por crecer es 1,7 veces lo que vale el crecimiento del NORMAL (17,20 € frente a 10,06 €).
- **Tornado**: la palanca que más mueve el valor es la tasa de descuento (±1 punto: 10,80 €), que es la r heredada. Es información, no criterio: el valor depende sobre todo de la rentabilidad exigida.
- **Semáforos**: margen por encima del Q3 del sector en los tres escenarios (G5, justificado en la fase B); r del 9,0 % por debajo de la r mínima del 9,5 % (heredada, se informa). Crecimiento, ROIC marginal, ROIC terminal, peso del terminal, S2C medio y orden de escenarios pasan. Cuota implícita sin calcular porque C24 está vacía.
- **Veredicto de la hoja** (A6): «DESCARTADA POR FILTRO PABRAI» por C13 = No. Mi cubo es Vigilar: es el caso típico de buen negocio sin margen claro en el precio.

Lo que no cuadra a primera vista, y cómo lo resuelvo:

1. **La rentabilidad del capital nuevo del NORMAL frente a la de la década.** El NORMAL rinde un 14,6 % por euro nuevo. En la Historia, el NOPAT creció ≈40 M€ para 436 M€ de capital nuevo entre 2016 y 2025: ≈9 %, y ≈7,6 % entre 2021 y 2025 [cálculo Historia filas ebit y capital_invertido, con t = C52]. No es una palanca mal derivada: el S2C es el de la Historia (C53, 1,15) y el margen es la media de 2019-2025 (16,4 %). La rentabilidad incremental histórica es baja porque el margen de toda la base cayó del 21,1 % al 16,4 % y porque en 2022-2023 el circulante subió 106 y 83 M€ (Historia, fila circulante). El NORMAL dice que el margen deja de caer; si sigue cayendo, es el MALO, que ya lleva un S2C de 0,9 con ese circulante dentro. Se resuelve con palabras, pero es la hipótesis de la que más depende el precio de Sí y la nombro en el punto 8.
2. **El FCF del NORMAL crece un 6,2 % anual y C25 = No.** Es mecánica: el crecimiento baja del 4,5 % al 2 % y con él la reinversión, así que el flujo crece más que las ventas. C25 mira el pasado, que lleva el circulante de 2022-2023 y el capex de 115,6 M€ de 2022. Coherente si no se repite ese choque, que es justo el MALO.
3. **El tipo impositivo del motor.** C52 (19,8 %) es la media de cinco años e incluye el 10,1 % de 2025 por la activación de bases negativas en EE. UU. (18,0 M€; extracto AR_2025 p. 142), que no se repite. La media de 2020-2024 es el 22,5 % [cálculo Historia fila tipo_impositivo]. Es una celda de datos y no la toco. Mi estimación proporcional al NOPAT (no es un recálculo de la hoja): el valor y el precio de Sí bajarían alrededor de un 3 %. Ni el cubo ni la zona cambian. Lo anoto para la ficha.
4. **Deuda y acciones en la misma fecha.** El motor B resta 279,9 M€ (deuda, arrendamientos, pensiones y minoritarios menos caja de diciembre de 2025) y divide por las acciones de diciembre de 2025. La deuda de junio de 2026 es mayor (C54, 375,75 M€) porque se compraron acciones: las dos fechas son coherentes entre sí. Lo que el modelo no recoge es que recomprar a un precio superior a mi NORMAL resta valor a quien se queda (programa de hasta 150 M€ hasta marzo de 2027, extracto AR_2025 p. 145).

Las 52 celdas cuentan una sola historia. No pido mover ninguna palanca.

## 2. Desviaciones pendientes

`gramatica.md` deja una sin justificar: **G8 en el BUENO** (salto de 8,2 puntos). G16 y G17 no aparecen: el peso del terminal no pasa del 63 % y la cuota implícita no se calcula. Las tres G5 ya están justificadas en la fase B.

**G8 · BUENO · fundamentada.** En los años 1–10 cada euro nuevo rinde un 20,2 % (1,4 × 0,18 × (1 − 0,198)) porque se juntan dos cosas que solo ocurren una vez. Una: se llena capacidad ya pagada (EE. UU., México, Serbia y Tailandia, extracto AR_2025 p. 65; el 37 % del capex de 2025 fue a capacidad, extracto AR_2025 p. 143). Dos: el margen sube del 16,4 % al 18,0 % al repartir costes fijos. Es crecimiento por eficiencia y es finito (GV p. 32; I1). Cuando el margen llega al techo de 2019-2025 (H29) y las plantas están llenas, el euro nuevo vuelve a pagar planta nueva a coste completo y rinde lo que rindió el capital en el peor año de la década: 12,1 % en 2019 (F33). En el año 11 no se pierde el foso: se acaban la capacidad ociosa ya pagada y el recorrido de margen. El 12 % sigue 3,7 puntos por encima de la tasa del motor (8,3 %). Tengo precedente propio en las dos direcciones: entre 2019 y 2025, saliendo del mínimo de margen, el capital incremental rindió ≈19,5 %; entre 2016 y 2025, ≈9 % [cálculo Historia]. «The question of how long your period in the sun will be is a very good one» (AIWTK p.127; HIM). No cambio la clase ni la cifra de D18. Lo cuento en la tesis.

## 3. ¿Hay que mover palancas?

No. Comprobé la aritmética de la fase B contra la Historia: crecimiento medio de 2017-2025 sin 2022 del 4,18 %, CAGR de 2016-2021 del 5,8 %, margen medio de 2019-2025 del 16,44 %, S2C de 1,19 (2016-2025), 2,03 (2016-2021) y 0,89 (2021-2025), y rentabilidades marginales del 10,8 %, 14,6 % y 20,2 %. Todo cuadra. El S2C del NORMAL (1,1) es C53 = 1,146 redondeado a 0,1. No encuentro ningún perímetro ni dato equivocado. Las tensiones del punto 1 se resuelven con palabras. La del tipo impositivo es de una celda de datos y no se arregla moviendo palancas. No cambio celdas. En `celdas_corregidas` registro que revisé C62 y C18 de la fase A y que las mantengo.

## 4. Autocomprobación

1. **Anclaje en la etapa 1.** La etapa 1 dejó Vigilar con precio de Sí de 25,1 €, g de 0,01 / 0,02 / 0,025 y un C104 con un porcentaje. Revisé las g: la del MALO casi no mueve el valor (ROIC terminal = tasa) y la del NORMAL está por debajo de la referencia (0,025) por un argumento propio (población más un punto de precio, sustitución que se agota). Cambio: ninguno en palancas. En el turno 2 B101, B102 y C104 se reescriben: los heredados llevan hechos de 2T26 y una cifra de 25,1 € que no salen de mis extractos, y C104 lleva un porcentaje que D16 prohíbe.
2. **Anclaje en el precio o en la fuente externa.** Los valores (35,4 / 47,6 / 63,3) no se acercan a los 54,70 €: el NORMAL queda un 13 % por debajo. La única probabilidad que moví la subí hacia el MALO, lejos de la cotización. No usé ningún valor razonable de terceros. Cambio: ninguno.
3. **Consistencia y compromiso.** El cubo Vigilar se decidió en la fase A, antes de los números. Prueba de que no ajusté palancas para que saliera: el precio descuenta un 8,2 % de crecimiento, más que mi BUENO y que la mejor racha de la década. Ningún NORMAL defendible lleva el precio a la zona de la regla. Cambio: ninguno.
4. **Historia bonita / viento de cola atribuido a la empresa.** Del 4,5 % del NORMAL, unos 3 puntos son del nicho (volumen del mercado del 2-4 %, extracto AR_2025 p. 181; tripa animal del 47 % al 44 %, extracto AR_2020 p. 110 y AR_2023 p. 145), un punto es precio que solo sigue al coste y medio punto es cuota. Lo de la empresa (cuota y margen) solo pesa en el BUENO, con un 0,15. Cambio: ninguno; la tesis dirá que el crecimiento es del nicho.
5. **Optimismo del BUENO frente a la tasa base.** El BUENO pide un 7 % de crecimiento (la mejor racha dio un 5,8 %) y un 20,2 % por euro nuevo en los años 1–10, más que el mejor ROIC de la década (16,7 %). Solo tiene precedente saliendo de un mínimo (2019-2025). Sus ventas del año 10 (2.167 M€) serían ≈32 % del valor del mercado si este crece al 3 % (de 4.400 M€ en 2020 a 5.100 M€ en 2025, extracto AR_2025 p. 181), frente a ≈24,5 % hoy: siete puntos en diez años, cuando la cuota de definición B ganó once en siete (2015-2022). Plausible, en el borde. Ya pesa menos que el MALO. Cambio: ninguno en celdas; justifico G8 y lo llamo la historia menos probada.
6. **Doble castigo del mismo riesgo.** La deuda solo la resta el motor B (279,9 M€): no está en la r ni en la quiebra (0, argumentada con dos disparadores) ni en la probabilidad. El margen aparece una vez como gravedad (15 % en el MALO) y otra como frecuencia (0,25): son dos cosas distintas. Lo observado desde 2019 son 2 años de 7 en ese nivel (2019 y 2023). La r (9 %) está por debajo de la mínima: si acaso perdona. Cambio: ninguno. Una probabilidad de quiebra sobre un riesgo que ya está en el MALO sería contarlo dos veces (PA pp. 20–21; E6).
7. **Disponibilidad (lo vívido del extracto).** Lo vívido son la «inflación sustancial» de las pieles, las coberturas de dólar superadas (extracto AR_2025 p. 436) y el EBITDA de 1S26 un 7,4 % menor (nota de C42). Esa caída es reportada e incluye el dólar, que ya es parte del mecanismo del MALO. Lo contrasté con lo menos vívido, la fila 29 de la Historia: el 0,25 cabe en la frecuencia observada (2 de 7 años) y no solo en el titular. «An idea or a fact is not worth more merely because it is easily available to you» (PCA p.587; HIM). Cambio: ninguno.
8. **Autoridad (guía de la dirección como hecho).** No copié la guía de 2026 (+5-7 %): el NORMAL es un 4,5 %. Los objetivos de Beat'30 no constan y el «potencial de más de 5.000 M€» de nuevos negocios no entra en ninguna palanca. Pero la cuota (30 % → 41 %) es una estimación de la empresa y la usé para C18 y el BUENO. C18 se sostiene igual con la serie de ROIC de las cuentas (Historia fila 33). «will frequently be a lie» (TCI p.60; HIM). Cambio: en el turno 2 la tesis dirá que la cuota es estimación de la dirección.
9. **¿El MALO es de verdad malo?** Sí. Lleva a perpetuidad el margen mínimo (15 %), que solo se vio en años sueltos (2019, 2023) seguidos de recuperación, con un ROIC terminal igual a la tasa: vale 35,39 €, menos que el valor sin crecimiento (37,50 €). Es más duro que cualquier tramo de varios años de la Historia. No cubre perder cuota o volumen: en diez años las ventas solo cayeron en 2024 (−1,8 %, K28), con cuota ganada (extracto AR_2025 p. 137). Por eso no es un suelo. «We don't think because it's never happened that it won't» (AIWTK p.55; HIM). Cambio: ninguno en palancas; la tesis inversa contará la pérdida de cuota como lo que el MALO no recoge.
10. **Lo no numerable que pesa y no está en las palancas.** Hay tres cosas. La primera: las recompras a un precio por encima de mi NORMAL, pagadas con deuda a corto (programa de hasta 150 M€, extracto AR_2025 p. 145; 145,1 M€ entre dividendos y recompras en 2025 con un FCF de 93,8 M€, extracto AR_2025 p. 144 e Historia fila 35). La segunda: las «acusaciones en Danville» sin desenlace (extracto AR_2025 p. 150). La tercera: un competidor que no sé nombrar. «practically everybody (1) overweighs the stuff that can be numbered» (PCA pp.412–414; HIM). Cambio: van a la tesis inversa, a B222 y a C98 como evidencia, no a una palanca.

## 5. Cubo y conclusión provisionales

En orden de mando. Bloqueo: no hay (0 errores de gramática; el estado técnico INCOMPLETO solo espera las predicciones del turno 2). Límite del modelo: no hay; el motor B calcula los tres escenarios. Descalificadores: ninguno aplica (fase A, sección 3). Dato ausente material: ninguno (punto 6). Fundamento material: la lista está vacía (punto 7). Y por último la zona: **caro**, porque 54,70 € está por encima del ponderado (46,88 €). El precio de Sí es 43,05 € (P\*; el tope del NORMAL no actúa) y está a un 21 % del precio actual. La regla antigua de la hoja (C156) da 35,16 €.

**Cubo provisional: Vigilar. Conclusión provisional: `esperar`, con precio de Sí ≤ 43,05 €.** «We just said that we wouldn't buy it or recommend that our friends buy it at the prices then prevailing» (PCA p.267; HIM). La escalera es una convención experimental (k = 3) y la zona no mide el riesgo.

## 6. Datos ausentes (S-19)

Revisé los 21 datos de `datos_ausentes.json` uno a uno (detalle en el JSON). Ninguno es material para `esperar` con precio objetivo. Los que más se acercan:
- **Competidores, cuota desde 2022, desglose de volumen, precio y mezcla, y margen por segmento o región.** Afectan a por qué cayó el margen y a cuánto dura. Pero la escalera usa el margen consolidado, y los tres escenarios cubren el rango observado en diez años (15,1-21,1 %), con el MALO en el mínimo y un 0,25. Serían materiales para un `comprar` que dependiera del BUENO; no lo son para esperar a 43,05 €.
- **Covenants, rating y calendario de renovación.** Afectan a C22 = 0. La deuda neta es 1,13 veces el EBITDA, el EBIT pasó de 130 M€ todos los años, hay 155,3 M€ de líneas libres (extracto AR_2025 p. 98) y la nota de C33 de fase 1 dice que la empresa cumple los covenants. Para que la quiebra pesara haría falta un umbral por debajo de 1,13x, algo que nada sugiere.
- **Tamaño del mercado a diez años (C24).** Sin cifra primaria la hoja no calcula la cuota implícita. La hice a mano con el valor de 2025 (punto 4, tendencia 5) como información.

## 7. Fundamento material (D10)

Recorrí las hipótesis materiales: B14:D16, B18:D18, B68:D69, C22, C23, C76, C44, C62, C8, C6 y B65:D66. Ninguna es de clase «sin juicio propio» ni «técnico». Todas las Observaciones citan hechos con celda de la Historia o página del extracto. Las seis narrativas tienen mecanismo y «qué lo pararía» con hechos de esta empresa (pieles, extracto AR_2025 p. 436; mezcla, p. 139; capacidad, p. 65; Pet Mania, p. 140). Miré con más cuidado las palancas que coinciden con su referencia (B16, C16, D16, B18, D18, C15). Cada una tiene su propio hecho y un rango acotado por cifras de la Historia, así que no son copias disfrazadas. C97 (insiders, técnico) y C56 (r heredada, S-3) no son hipótesis materiales en el sentido de §B.6: no mueven ningún valor de la escalera. **Lista vacía.**

La conclusión provisional no es favorable: `resultado = no_procede` y no hago la comprobación conjunta. `sobrevive` queda en null. El precio objetivo no queda marcado como provisional por D10. Sí arrastra la nota del tipo impositivo (punto 1.3): alrededor de un 3 % optimista.

## 8. La hipótesis que más condiciona y qué la resolvería

La lista está vacía, así que la nombro por juicio y no por el tornado: **C15 y C18 del NORMAL. El margen deja de erosionarse en el 16,5 % y el capital nuevo rinde un 11 % a perpetuidad.** De ella depende el precio de Sí: la década muestra un margen del 21,1 % al 16,4 % y una rentabilidad incremental de ≈9 %. «how much is going to stay home and how much is just going to flow through to the customer» (PCA pp.187–189; HIM).

**Qué la resolvería:** el desglose de la variación de ventas y de margen en volumen, precio, mezcla y coste de pieles por tecnología, que no se publica (extracto AR_2025 p. 139); se pide a Relación con Inversores. Y el margen EBIT consolidado del informe anual de 2026: si es de al menos el 16 % con las pieles caras, confirma el NORMAL; si baja del 15 %, lo desplaza hacia el MALO.

## 9. Turno 2 · comprobación conjunta

No existe `comprobacion_conjunta.json`: con conclusión `esperar` y lista vacía no procedía. `sobrevive` queda en null y `resultado` en `no_procede`. No hay rango del precio de Sí bajo combinación que informar.

## 10. Conclusión

**Estado `concluido` (provisional hasta la auditoría) · cubo Vigilar · acción `esperar` · precio objetivo 43,05 €** (precio de Sí de `precio.json`). En orden de mando: no hay bloqueo, límite del modelo, descalificador, dato ausente material ni hipótesis material sin fundamento. Manda la zona, `caro`: 54,70 € está por encima del ponderado (46,88 €) y del NORMAL (47,56 €). La escalera es convención experimental (k = 3). El precio del MALO (35,39 €) no es un suelo. El precio objetivo arrastra la nota del tipo impositivo (punto 1.3): alrededor de un 3 % optimista.

C104: «Pendiente de decisión de cartera · conclusión del personaje: esperar: precio de Sí ≤ 43.05 · zona caro · precio de Sí ≤ 43.05 · precio esc. MALO 35.39 · ponderado 46.88 · fundamento lista vacía». La decisión de cartera es de José Luis.

El veredicto de la hoja (A6, «DESCARTADA POR FILTRO PABRAI») y mi cubo difieren por C13 = No: la hoja descarta lo que no es barato a ojo; yo vigilo un buen negocio que entiendo a un precio sin margen. «We just said that we wouldn't buy it or recommend that our friends buy it at the prices then prevailing» (PCA p.267; HIM).

C93 = Sí. El g del NORMAL (2 %) se sostiene: el terminal reinvierte el 18 % del NOPAT a un ROIC del 11 %, el salto del año 11 es de 3,6 puntos y el terminal pesa el 59 %. C103 = No: el foso existe pero rinde cada vez menos (margen del 21,1 % al 16,4 %). «most big businesses eventually fall into mediocrity or worse» (AIWTK p.140; HIM).

## 11. Tesis (B101)

Viscofan fabrica envolturas para embutidos en 22 plantas, para más de 1.700 clientes, y ninguno pesa más del 10 % (extracto AR_2025 pp. 121 y 137). Su ROIC no bajó del 12,1 % en diez años (Historia fila 33): es un buen negocio de nicho con un foso de escala y proceso. Pero el foso rinde menos. El margen EBIT pasó del 21,1 % al 16,4 % mientras la cuota que estima la propia empresa subía del 30 % al 41 % (extracto AR_2022 p. 200). El crecimiento es sobre todo del nicho. Mi NORMAL vale 47,56 €. A 54,70 € el precio descuenta un 8,2 % de crecimiento anual (C86), más que mi BUENO, y la dirección recompra por encima de mi NORMAL con deuda a corto (extracto AR_2025 pp. 144-145). Vigilar con precio de Sí de 43,05 €.

## 12. Tesis inversa (B102)

Defiendo el No con hechos.

- **Costes que no controla.** El consumo de materias primas pasó de 370,5 a 411,6 M€ en 2025 (extracto AR_2025 p. 23), las pieles europeas sufren «inflación sustancial» y las coberturas de dólar fueron superadas (p. 436).
- **Cuota pagada con precio.** La cuota sube, pero el margen cayó 4,7 puntos en diez años (Historia C29, L29) y en 2025 la mezcla fue inferior con volumen récord (p. 139).
- **El capital nuevo apenas rinde su coste.** El capital invertido creció 436 M€ en 2016-2025 y el NOPAT solo ≈40 M€: ≈9 %, frente a una tasa del motor del 8,3 % [cálculo Historia].
- **Reparte más caja de la que genera.** La caja libre al accionista no crece desde 2019 (Historia fila 35). Aun así pagó 145,1 M€ al accionista en 2025 (p. 144) y la deuda pasó de 116,8 a 304,1 M€, con 227,4 M€ de bancos a un año (p. 98).
- **Lo que no sé.** No sé quién es el competidor que gana ni en qué quedó Danville (p. 150). Pet Mania perdió actividad por un arancel (p. 140).
- **El precio frente al MALO.** Con el margen del peor año, la hoja da 35,39 € (B78) y el mercado paga un 55 % más. Y ese MALO aún no recoge perder cuota.

## 13. Predicciones (dado el NORMAL)

1. Ventas de 2027 entre 1.330 y 1.450 M€ · 2028-03-31 · 0,65.
2. Margen EBIT de 2027 entre el 15,5 % y el 17,5 % · 2028-03-31 · 0,6.
3. Pagos por inmovilizado de 2027 de no más de 1,3 veces la amortización · 2028-03-31 · 0,7.

Las tres son sobre el negocio y se comprueban con el informe anual de 2027. Son la autopsia de este análisis: «comparing predictions with outcomes» (PCA p.606; HIM).

## 14. B222 y B223

- **B222:** la hipótesis fundamentada de la que más depende el precio de Sí. El margen deja de erosionarse en el 16,5 % (C15) y el capital nuevo rinde un 11 % (C18).
- **B223:** el desglose de volumen, precio, mezcla y coste de pieles por tecnología, que se pide a Relación con Inversores, y el margen EBIT del informe anual de 2026. Si es de al menos el 16 %, confirma el NORMAL; si baja del 15 %, lo desplaza al MALO.

## 15. Qué me haría cambiar de cubo

- **A Sí:** un precio de 43,05 € o menos con el NORMAL intacto. O un margen de al menos el 17,5 % dos años con cuota publicada al alza.
- **A No:** un margen por debajo del 15 % dos años con ventas planas; una deuda neta por encima de 2,5 veces el EBITDA para seguir pagando al accionista; o que Danville revele un problema de integridad.
- **A Demasiado difícil:** que la caída del margen venga de un sustituto tecnológico que no pueda juzgar, o una compra grande fuera del nicho.

## 16. Comparación con la etapa 1

Coinciden el cubo (Vigilar) y la razón: precio sin margen. El precio de Sí sube de 25,1 € a 43,05 € por tres cambios:

- **Motor.** La etapa 1 valoró el FCF al accionista sin restar deuda; yo valoro con el motor B y resto 279,9 M€.
- **MALO.** El suyo era caja plana; el mío es el margen mínimo de diez años, y vale 35,39 €.
- **Regla.** La suya era mín(MALO, 0,75 × ponderado), que en esta hoja daría 35,16 € (C156); la mía es la escalera k = 3.

La etapa 1 acertó en que el precio descuenta más crecimiento del que la empresa ha dado. Se equivocó al usar como hechos datos de 2T26 que no están en mis extractos y al poner un tamaño de posición, que no me corresponde.
