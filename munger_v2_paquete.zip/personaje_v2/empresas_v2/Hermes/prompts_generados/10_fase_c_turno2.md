# Paso 10 · fase_c_turno2

Entradas (en /home/user/Joselito/personaje_v2/empresas_v2/Hermes): fase_c.json (turno 1), comprobacion_conjunta.json (si existe)

Salida esperada: fase_c.json

Rutas:
- carpeta de la empresa: /home/user/Joselito/personaje_v2/empresas_v2/Hermes
- raíz del personaje v2 (personaje_munger_v2.md, ANEXO_*.md, ENCARGO_personaje_v2.md, scripts/, esquema/): /home/user/Joselito/personaje_v2
- corpus Munger (munger.md): /home/user/Joselito/kit_pipeline_munger/munger.md
- corpus Damodaran (damodaran.md, si existe): /home/user/Joselito/personaje_v2/corpus/damodaran.md
- modelo y esfuerzo previstos (config_v2.json → modelos): {"modelo": "opus", "esfuerzo": "alto", "turnos": 2}

**CORRECCIÓN pedida por el pipeline:** segundo turno de la fase C: lee comprobacion_conjunta.json (si existe) y cierra fase_c.json (turno 2)

---

# Prompt de la FASE C · segundo turno · Conclusión, celdas y predicciones (modelo: Opus, esfuerzo alto, mismo contexto que el turno 1 si es posible)

Sigues siendo el analista de `personaje_munger_v2.md` (secciones 15, 16 y 17). En este turno haces los puntos (6) a (9) del encargo §4.5.

## Entradas
- `/home/user/Joselito/personaje_v2/empresas_v2/Hermes/fase_c.json` (tu turno 1). Damodaran, mientras no exista `corpus/damodaran.md`: solo por documento y principio, sin página ni frase literal. Páginas de los extractos: `(extracto p. 14)`.
- `/home/user/Joselito/personaje_v2/empresas_v2/Hermes/comprobacion_conjunta.json` (si existe): lo que la hoja produjo con tu combinación en una copia de prueba, con recálculo forzado: `resultados_bajo_combinacion`, `escalera_bajo_combinacion`, `escalera_original` y `sobrevive` (booleano: la zona del precio actual sigue en `cumple_regla_k` o `bajo_malo` y no apareció ningún error).
- Lo mismo del turno 1 (`precio.json`, `resultados.json`, `datos_v63.md`, extractos) para escribir las celdas.

## Qué haces
1. **Comprobación conjunta**: copia `sobrevive` tal cual en `fundamento_material.comprobacion_conjunta.sobrevive` (déjalo `null` si no existe `comprobacion_conjunta.json`). **Solo manda sobre la conclusión favorable**: con conclusión provisional `comprar`, si sobrevive puedes mantenerla (`resultado = comprobacion_conjunta_superada`) y la presentas como «comprobación conjunta superada: no es una garantía de seguridad; su fuerza depende de los rangos que yo haya encontrado defendibles»; si no sobrevive, `pendiente_de_investigacion`. Con `esperar`, `descartar` o `demasiado_dificil` el `resultado` es `no_procede` y la escalera bajo la combinación, si la hubo, se informa como rango del precio de Sí (no cambia el estado). No reinterpretes el booleano ni propongas otra combinación.
2. **Estado, cubo y acción** (sección 15, mapa cerrado): `concluido` (provisional hasta la auditoría) con Sí ⇔ `comprar` (solo con `fundamento_material.resultado` = `sin_limitacion` o `comprobacion_conjunta_superada`, zona `cumple_regla_k` o `bajo_malo`, sin descalificadores, `alguno_material = false`); Vigilar ⇔ `esperar` (precio objetivo = precio de Sí de `precio.json`; si la zona ya cumple la regla, `condicion` concreta y comprobable que no sea de precio); No ⇔ `descartar`; Demasiado difícil ⇔ `demasiado_dificil`. `pendiente_de_investigacion` → cubo Vigilar, acción `null`, `resultado = pendiente_de_investigacion`. `alguno_material = true` (S-19) → `estado_analisis = pendiente_de_datos`, cubo Vigilar, acción `null`, `resultado = no_procede`. `limite_del_modelo.aplica` → `modelo_no_aplicable`, cubo cualitativo, `descartar`/`demasiado_dificil` o acción `null`; nunca `comprar` ni `esperar`; en ese caso las 16 celdas y sus Observaciones no se escriben en el libro (puedes dejarlas a `null`) y, si corriges `C62`, va en `celdas_corregidas` con `antes`, `despues` y `motivo`. `fundamento_material.resultado` ∈ {`sin_limitacion`, `comprobacion_conjunta_superada`, `pendiente_de_investigacion`, `no_procede`}.
3. **Las 16 celdas** (`celdas`, claves `C93`, `C103`, `C104`, `B101`, `B102`, `Palancas!A38`…`Palancas!C40`, `Diagnóstico V6!B222`, `Diagnóstico V6!B223`) con sus `observaciones` (las 14 con fila en Control maestro: todas menos B222/B223; formato de la sección 17, `Hereda:` en C93, B101, B102, C103, C104; `Hereda: nueva en V6.3.` en las de Palancas):
   - `C93` ¿g NORMAL sostenible? después de ver el salto del año 11 y el peso del terminal. `C103` «nunca vender» es propiedad del negocio, no de si se compra.
   - `C104` exactamente: «Pendiente de decisión de cartera · conclusión del personaje: <comprar al precio actual | esperar: precio de Sí ≤ P | descartar (No) | demasiado difícil | sin conclusión (pendiente de investigación) | sin conclusión (pendiente de datos: <celdas>)> · zona <zona> · precio de Sí ≤ P · precio esc. MALO Q · ponderado R · fundamento <lista vacía | comprobación conjunta superada | pendiente de investigación | pendiente de datos>», con los tres números de `precio.json` (`precio_si`, `precio_escenario_malo`, `ponderado`) copiados con 0–2 decimales y sin separador de miles (`1250.4`, no «1.250,4»); si `precio_escenario_malo` es `null` (B78 ≤ 0) escribe «precio esc. MALO: sin precio»; con `descartar` o `demasiado difícil` puedes sustituir los tres por «sin escalera aplicable». **Sin ningún porcentaje** (ni el símbolo %, ni «0 %»). El tamaño de la posición es de José Luis. `decision.precio_objetivo`, con `esperar`, es exactamente el `precio_si` de `precio.json` (como mucho redondeado a dos decimales).
   - `B101` tesis en ≤ 5 frases con hechos. `B102` tesis inversa: defender el No mejor que un bajista, con hechos y celdas o páginas (el verificador lo exige).
   - Predicciones `Palancas!A38:A40`: tres, sobre el negocio (ventas, margen, unidades, cuota publicada, capex, deuda; nunca el precio de la acción ni macro: el script rechaza cualquier predicción que contenga «cotización», «precio de la acción», «precio objetivo», «PIB», «inflación» o «tipos de interés», aunque sea de pasada), falsables con datos que la empresa publica; `B38:B40` fecha ISO `AAAA-MM-DD` a 12–24 meses de `Análisis!D4`; `C38:C40` probabilidad de que **cada predicción** se cumpla dado el escenario NORMAL (decimal, no la probabilidad del escenario).
   - `B222` la hipótesis sin fundamento que más condiciona la conclusión (o, con lista vacía, la fundamentada de la que más depende según tu juicio); `B223` el dato o documento concreto que la resolvería (qué informe, qué nota, qué pregunta a Relación con Inversores).
4. `herencia` de C93, B101, B102, C103, C104 (`etapa1` copia el valor literal de la etapa 1, aunque sea «0% · Watchlist»: es un dato histórico, no tu C104; `decision`, `motivo`, `evidencia_y_razonamiento` que nombre la evidencia; sección 13). `comparacion_etapa_1` honesta (cubo y precio de Sí v1 contra v2 y por qué difieren; si el v1 no tenía precio de Sí, `null`). `cambiaria_de_cubo` (a Sí, a No, a Demasiado difícil: hechos concretos). `insumos_decision_cartera` con los números de `precio.json`, el estado del fundamento, los datos ausentes materiales, los descalificadores considerados, `r` y `r_minima`, y la palanca más influyente como información. `decision.condiciones_revision` (al alza, a la baja). `confianza_global`.
5. Repasa la **checklist de la fase C** (sección 17) y la regla de hechos y juicios: cada hecho con celda o página; lo demás como juicio.

## Lo que NO haces
No cambias nada del turno 1 salvo `sobrevive` y lo que el orquestador te haya pedido corregir. No abres Excel. No buscas en internet. No escribes porcentajes de posición. No escribes `Sí`/`comprar` con `pendiente_de_datos`, `pendiente_de_investigacion` ni `modelo_no_aplicable`.

## Salida
`/home/user/Joselito/personaje_v2/empresas_v2/Hermes/fase_c.json` completo (`turno: 2`, todas las claves del Anexo D §D.6) y `/home/user/Joselito/personaje_v2/empresas_v2/Hermes/fase_c.md` ampliado con la conclusión, la tesis y la tesis inversa, las predicciones, qué cambiaría el cubo y la comparación con la etapa 1. Sin preámbulos ni cierres. Comprueba con Bash: `python3 -m json.tool /home/user/Joselito/personaje_v2/empresas_v2/Hermes/fase_c.json > /dev/null`; `python3 scripts/fase_a_celdas.py /home/user/Joselito/personaje_v2/empresas_v2/Hermes/fase_c.json C /tmp/celdas_C_prueba.json` (código 0: las 16 celdas y sus 14 Observaciones); que `C104` no contiene «%»; `verify_quotes_v2.py` sobre `fase_c.md`. Responde al orquestador solo con: estado, cubo, acción y, si la hay, la condición o el precio objetivo.

## Citas de Damodaran (v2.1)
Si citas un principio de Damodaran con página, usa SOLO una página de `/home/user/Joselito/personaje_v2/corpus/paginas_principios.json` para ese principio y ese documento (formato «(CV p. 5; E1)»). Una página que exista pero no sostenga el principio cuenta como error: el pipeline lo comprueba en cuanto entregas (`verify_quotes_v2.py`) y te devuelve la salida. Antes de terminar, ejecuta tú `python3 /home/user/Joselito/personaje_v2/scripts/verify_quotes_v2.py --corpus <munger.md> --corpus /home/user/Joselito/personaje_v2/corpus/damodaran.md --paginas-estrictas` sobre tu .md y sobre un volcado de los textos de tu JSON, y corrige hasta PASS. Si no necesitas la página, cita solo documento y principio: «(CV; E1)».
